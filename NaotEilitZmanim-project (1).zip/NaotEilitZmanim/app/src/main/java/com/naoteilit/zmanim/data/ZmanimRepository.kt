package com.naoteilit.zmanim.data

class ZmanimRepository(
    private val api: NedarimPlusApi = NedarimPlusApi()
) {
    data class Result(
        val ourShul: List<Minyan>,
        val others: List<Minyan>
    )

    suspend fun fetch(
        lat: Double = Config.DEFAULT_LAT,
        lng: Double = Config.DEFAULT_LNG,
        radiusKm: Double = Config.DEFAULT_RADIUS_KM
    ): Result {
        val all = api.getNearbyMinyanim(lat, lng, radiusKm)
        val ours = all.filter { it.institutionId == Config.NAOT_EILIT_INSTITUTION_ID }
        val others = all.filter { it.institutionId != Config.NAOT_EILIT_INSTITUTION_ID }
        return Result(ourShul = ours, others = others)
    }
}
