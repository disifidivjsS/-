package com.naoteilit.zmanim.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.naoteilit.zmanim.data.Minyan
import com.naoteilit.zmanim.data.ZmanimRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed interface UiState {
    data object Loading : UiState
    data class Success(val ourShul: List<Minyan>, val others: List<Minyan>) : UiState
    data class Error(val message: String) : UiState
}

class ZmanimViewModel(
    private val repository: ZmanimRepository = ZmanimRepository()
) : ViewModel() {

    private val _state = MutableStateFlow<UiState>(UiState.Loading)
    val state: StateFlow<UiState> = _state.asStateFlow()

    init {
        refresh()
    }

    fun refresh() {
        _state.value = UiState.Loading
        viewModelScope.launch {
            try {
                val result = repository.fetch()
                _state.value = UiState.Success(result.ourShul, result.others)
            } catch (e: Exception) {
                _state.value = UiState.Error(e.message ?: "שגיאה לא ידועה בטעינת הנתונים")
            }
        }
    }
}
