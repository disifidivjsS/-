package com.naoteilit.zmanim.data

import android.annotation.SuppressLint
import android.content.Context
import android.webkit.WebView
import android.webkit.WebViewClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import org.json.JSONTokener
import java.io.IOException
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * Fetches a URL's raw body text using Android's built-in WebView (the real
 * Chromium engine) instead of a raw HTTP client like OkHttp.
 *
 * Why this exists: matara.pro appears to block/hang connections from
 * non-browser HTTP clients (likely basic bot protection at the network or
 * WAF layer) even though the exact same URL opens fine in Chrome. Since
 * WebView uses the same underlying browser engine as Chrome, requests made
 * through it look like a normal browser visit and are not blocked.
 */
object WebViewFetcher {

    @SuppressLint("SetJavaScriptEnabled")
    suspend fun fetchRawText(context: Context, url: String): String =
        withContext(Dispatchers.Main) {
            suspendCancellableCoroutine { cont ->
                val webView = WebView(context.applicationContext)
                webView.settings.javaScriptEnabled = true

                webView.webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView, loadedUrl: String) {
                        view.evaluateJavascript("document.body.innerText") { rawResult ->
                            // evaluateJavascript returns the value JSON-encoded
                            // (e.g. "\"{\\\"data\\\":...}\""), so decode it back
                            // into a plain string.
                            val decoded = try {
                                JSONTokener(rawResult).nextValue() as? String ?: rawResult
                            } catch (e: Exception) {
                                rawResult
                            }
                            if (cont.isActive) cont.resume(decoded)
                            view.destroy()
                        }
                    }

                    override fun onReceivedError(
                        view: WebView,
                        errorCode: Int,
                        description: String?,
                        failingUrl: String?
                    ) {
                        if (cont.isActive) {
                            cont.resumeWithException(
                                IOException("שגיאת טעינה: $description")
                            )
                        }
                        view.destroy()
                    }
                }

                cont.invokeOnCancellation { webView.destroy() }
                webView.loadUrl(url)
            }
        }
}
