package com.naoteilit.zmanim

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.naoteilit.zmanim.ui.HomeScreen
import com.naoteilit.zmanim.ui.OthersScreen
import com.naoteilit.zmanim.ui.ZmanimViewModel
import com.naoteilit.zmanim.ui.theme.NaotEilitZmanimTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            NaotEilitZmanimApp()
        }
    }
}

@Composable
fun NaotEilitZmanimApp() {
    // App always opens on the Naot Eilit screen, per the requirement.
    val viewModel: ZmanimViewModel = viewModel()
    var showOthers by remember { mutableStateOf(false) }

    NaotEilitZmanimTheme {
        Surface(modifier = Modifier.fillMaxSize()) {
            if (showOthers) {
                OthersScreen(viewModel = viewModel, onBack = { showOthers = false })
            } else {
                HomeScreen(viewModel = viewModel, onShowOthers = { showOthers = true })
            }
        }
    }
}
