package com.naoteilit.zmanim.data

/**
 * Verified against a real API response on 2026-09-15.
 * Institution "בית הכנסת המרכזי בשכונת נאות עילית" (Naot Eilit) matched by
 * name + smallest distance (127m) out of the full result set for this location.
 */
object Config {
    // The synagogue we filter for everywhere in the app.
    const val NAOT_EILIT_INSTITUTION_ID = "7015962"
    const val NAOT_EILIT_DISPLAY_NAME = "בית הכנסת המרכזי - נאות עילית"
    const val NAOT_EILIT_ADDRESS = "מהרי\"ל 7, מודיעין עילית"

    // Default search origin (from the original result.html link the user gave us).
    const val DEFAULT_LAT = 31.931201713080377
    const val DEFAULT_LNG = 35.04763733760363
    const val DEFAULT_RADIUS_KM = 1.0
}
