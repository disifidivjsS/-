package com.naoteilit.zmanim.data

/**
 * One prayer-time row as returned by the Nedarim Plus GetNearestMinyan endpoint.
 * Field names (T, L, H, C, D, M, A, W) come directly from the API's JSON keys.
 */
data class Minyan(
    val tefila: String,        // T - "שחרית" / "מנחה" / "ערבית" etc.
    val institutionName: String, // L - display name of the synagogue/minyan
    val hour: String,          // H - time of day, e.g. "19:15"
    val comment: String,       // C - free-text note, may be empty
    val distanceText: String,  // D - e.g. "383 מטר"
    val institutionId: String, // M - stable internal ID, used for filtering
    val address: String,       // A - address text
    val coords: String         // W - "lat*lng" of the institution itself
)
