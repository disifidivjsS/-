package com.naoteilit.zmanim.data

import android.content.Context
import org.json.JSONObject

/**
 * Thin client around the undocumented but functional endpoint the
 * matara.pro/nedarimplus/Zmanim/result.html page itself calls via AJAX:
 *
 *   GET https://www.matara.pro/nedarimplus/Zmanim/Manage.aspx
 *       ?Action=GetNearestMinyan&lat={lat}&lng={lng}&radius={radiusKm}
 *
 * IMPORTANT: this endpoint is not officially published for third-party use.
 * See the investigation report for details/caveats. Treat schema changes as
 * possible; all parsing below is defensive (optString, empty list fallback).
 *
 * NOTE ON FETCH METHOD: a plain HTTP client (OkHttp) reliably times out
 * against this host even though the same URL opens fine in Chrome on the
 * same device/network - consistent with basic bot protection blocking
 * non-browser clients. Fetching through WebViewFetcher (Android's real
 * Chromium engine) avoids that, at the cost of needing a Context and having
 * to run on the main thread.
 */
class NedarimPlusApi {

    companion object {
        private const val ORIGIN_URL = "https://www.matara.pro/"
        private const val BASE_URL =
            "https://www.matara.pro/nedarimplus/Zmanim/Manage.aspx"
    }

    suspend fun getNearbyMinyanim(
        context: Context,
        lat: Double,
        lng: Double,
        radiusKm: Double
    ): List<Minyan> {
        val url = "$BASE_URL?Action=GetNearestMinyan" +
            "&lat=$lat&lng=$lng&radius=$radiusKm" +
            "&_=${System.currentTimeMillis()}"

        val body = WebViewFetcher.fetchRawText(context, url, ORIGIN_URL)
        if (body.startsWith("ERROR:")) {
            throw java.io.IOException("שגיאת רשת: ${body.removePrefix("ERROR:")}")
        }
        return parseMinyanim(body)
    }

    private fun parseMinyanim(rawJson: String): List<Minyan> {
        if (rawJson.isBlank()) return emptyList()
        return try {
            val root = JSONObject(rawJson)
            val arr = root.optJSONArray("data") ?: return emptyList()
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Minyan(
                    tefila = o.optString("T"),
                    institutionName = o.optString("L"),
                    hour = o.optString("H"),
                    comment = o.optString("C"),
                    distanceText = o.optString("D"),
                    institutionId = o.optString("M"),
                    address = o.optString("A"),
                    coords = o.optString("W")
                )
            }
        } catch (e: Exception) {
            // Schema changed or malformed response - fail soft, not with a crash.
            emptyList()
        }
    }
}
