package com.naoteilit.zmanim.data

import android.annotation.SuppressLint
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.IOException
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * Fetches a URL's raw response text using Android's built-in WebView (real
 * Chromium engine) instead of a raw HTTP client like OkHttp, because
 * matara.pro appears to block/hang non-browser clients.
 *
 * Loading the JSON API URL directly in WebView doesn't work reliably (raw
 * JSON isn't a navigable HTML page, so WebView can silently hang with
 * neither onPageFinished nor onReceivedError firing). Instead: load a blank
 * page on the site's own origin, then run a normal JS `fetch()` from inside
 * that page - exactly what a real browser tab would do - and receive the
 * result back in Kotlin through a JavascriptInterface bridge. A hard 20s
 * timeout guarantees this never hangs forever even if something goes wrong.
 */
object WebViewFetcher {

    private const val TIMEOUT_MS = 20_000L

    private class JsBridge(private val onResult: (String) -> Unit) {
        @JavascriptInterface
        fun onResult(text: String) {
            onResult(text)
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    suspend fun fetchRawText(context: Context, url: String, originUrl: String): String =
        withContext(Dispatchers.Main) {
            suspendCancellableCoroutine { cont ->
                val handler = Handler(Looper.getMainLooper())
                var finished = false
                val webView = WebView(context.applicationContext)

                fun finishOnce(action: () -> Unit) {
                    if (finished) return
                    finished = true
                    action()
                    webView.destroy()
                }

                val timeoutRunnable = Runnable {
                    if (cont.isActive) {
                        finishOnce {
                            cont.resumeWithException(IOException("timeout - האתר לא הגיב תוך 20 שניות"))
                        }
                    }
                }
                handler.postDelayed(timeoutRunnable, TIMEOUT_MS)

                webView.settings.javaScriptEnabled = true
                webView.settings.domStorageEnabled = true

                webView.addJavascriptInterface(
                    JsBridge { text ->
                        handler.post {
                            handler.removeCallbacks(timeoutRunnable)
                            if (cont.isActive) {
                                finishOnce { cont.resume(text) }
                            }
                        }
                    },
                    "AndroidBridge"
                )

                webView.webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView, loadedUrl: String) {
                        val escapedUrl = url.replace("'", "%27")
                        val js = """
                            fetch('$escapedUrl', {credentials: 'omit'})
                              .then(function(r) { return r.text(); })
                              .then(function(t) { AndroidBridge.onResult(t); })
                              .catch(function(e) { AndroidBridge.onResult('ERROR:' + e); });
                        """.trimIndent()
                        view.evaluateJavascript(js, null)
                    }

                    override fun onReceivedError(
                        view: WebView,
                        errorCode: Int,
                        description: String?,
                        failingUrl: String?
                    ) {
                        handler.removeCallbacks(timeoutRunnable)
                        if (cont.isActive) {
                            finishOnce {
                                cont.resumeWithException(IOException("שגיאת טעינה: $description"))
                            }
                        }
                    }
                }

                cont.invokeOnCancellation {
                    handler.removeCallbacks(timeoutRunnable)
                    webView.destroy()
                }

                // Load a blank page on the site's own origin first, so the
                // fetch() call below behaves like a normal same-site request.
                webView.loadDataWithBaseURL(
                    originUrl,
                    "<html><body></body></html>",
                    "text/html",
                    "utf-8",
                    null
                )
            }
        }
}
