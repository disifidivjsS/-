package com.naoteilit.zmanim.ui.theme

import androidx.compose.ui.graphics.Color

val BlueMain = Color(0xFF1E4B8A)
val BlueDark = Color(0xFF0F2E5C)
val GoldAccent = Color(0xFFC9A227)
val BackgroundLight = Color(0xFFF7F5F0)
val CardWhite = Color(0xFFFFFFFF)
val TextPrimary = Color(0xFF1B1B1B)
val TextSecondary = Color(0xFF6B6B6B)
