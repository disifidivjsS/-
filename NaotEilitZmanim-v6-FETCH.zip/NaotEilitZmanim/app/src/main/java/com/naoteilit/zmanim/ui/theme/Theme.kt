package com.naoteilit.zmanim.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

// Declared first, since Kotlin initializes top-level properties in file order
// and LightColors/DarkColors below reference these.
private val ColorWhite = Color.White
private val ColorBlack = Color.Black

private val LightColors = lightColorScheme(
    primary = BlueMain,
    onPrimary = ColorWhite,
    secondary = GoldAccent,
    background = BackgroundLight,
    surface = CardWhite,
    onBackground = TextPrimary,
    onSurface = TextPrimary
)

private val DarkColors = darkColorScheme(
    primary = GoldAccent,
    onPrimary = ColorBlack,
    secondary = BlueMain,
    background = BlueDark,
    surface = Color(0xFF17335E),
    onBackground = ColorWhite,
    onSurface = ColorWhite
)

@Composable
fun NaotEilitZmanimTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColors else LightColors
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colorScheme.primary.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = AppTypography,
        content = content
    )
}
